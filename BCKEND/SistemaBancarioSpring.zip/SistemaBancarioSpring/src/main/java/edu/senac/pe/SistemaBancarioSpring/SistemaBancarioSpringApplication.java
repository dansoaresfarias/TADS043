package edu.senac.pe.SistemaBancarioSpring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SistemaBancarioSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(SistemaBancarioSpringApplication.class, args);
	}

}

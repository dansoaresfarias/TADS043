package edu.senac.pe.SistemaBancarioSpring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaBancarioSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
